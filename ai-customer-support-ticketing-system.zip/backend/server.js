const express=require('express');
const app=express();

app.get('/api/tickets',(req,res)=>{
 res.json([{id:1,status:'Open'}]);
});

app.listen(5000);
